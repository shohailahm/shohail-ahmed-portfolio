---
name: reel-skill-chat
description: "The reel skill for Claude chat. Makes motion-graphics Instagram reels (1080x1920 MP4 with sound) for the user's page from a checked source, step by step with the user's yes at each stop, and learns the user's taste with every reel. Also finds reel ideas and made-up story ideas, writes captions and Threads posts, saves sources, reviews post numbers and picks what to make next. Use when the user asks to make a reel, a motion-graphics video or an animated lesson, wants reel ideas or a made-up story, asks for a caption, asks what to do today or how a post did, pastes a link to save, or wants to set up their page."
---

# Reel skill for chat

> Free from @barakahraaz on Instagram. Not for sale.

This one skill is the whole reel studio. It holds the flows the user asks for, the five helpers, and the reel chain that makes the video. Each part is its own file in `references/sections/`, listed in the table at the end. Read only the file a step needs, when it needs it. Never read them all: every file you read stays in the chat and costs the user usage.

The user never types a command. They say plain words, and the Project instructions match them to a flow. When a file says "the `creator:reel` flow", read `references/sections/flow-reel.md`. When it says "the Coach", read `references/sections/helper-coach.md`. When it says `mg-reel-style`, read `references/sections/mg-reel-style.md`.

## Find the skill folder

This SKILL.md sits in the skill folder. Find it once, at the start of the chat:

```text
find / -name SKILL.md -path "*reel-skill-chat*" 2>/dev/null | head -1
```

The folder of that file is the skill folder. It is read-only, so the setup below copies the engine to a folder you can write in.

## Setup

Code execution must be on (Settings, Capabilities). Run this once per chat, as one command, before any reel work:

```bash
SKILL="$(dirname "$(find / -name SKILL.md -path "*reel-skill-chat*" 2>/dev/null | head -1)")"
W=/home/claude/creator
E="$W/.engine"
mkdir -p "$E" "$W/03 - export" "$W/00 - notes/content"
cp -R "$SKILL/scripts" "$SKILL/references" "$E/"
tar xzf "$SKILL/assets.tar.gz" -C "$E"
[ -f "$W/00 - notes/ledger.md" ] || cp -R "$E/assets/vault/00 - notes/." "$W/00 - notes/"
REEL_CHROME="$(ls -d /opt/pw-browsers/chromium-*/chrome-linux*/chrome 2>/dev/null | head -1)"
G="$(npm root -g)"
if [ -d "$G/playwright" ]; then
  NODE_GLOBAL="$G"
else
  if [ ! -d "$G/playwright-core" ]; then
    V="$(python3 -c "import importlib.metadata as m; print(m.version('playwright'))" 2>/dev/null)"
    npm i -g "playwright-core${V:+@$V}" >/dev/null 2>&1 || npm i -g playwright-core >/dev/null 2>&1
  fi
  G="$(npm root -g)"
  mkdir -p "$W/.node"
  ln -sfn "$G/playwright-core" "$W/.node/playwright"
  NODE_GLOBAL="$W/.node"
fi
cat > "$E/env.sh" <<EOF
export REEL_CHROME="$REEL_CHROME"
export NODE_GLOBAL="$NODE_GLOBAL"
export REEL_OUT="$W/03 - export"
export REEL_TABS=2
EOF
. "$E/env.sh"
[ -f "$E/scripts/render.sh" ] && echo "engine ok" || echo "missing: engine"
[ -x "$REEL_CHROME" ] && echo "chromium ok" || echo "missing: chromium"
node -e "require(process.env.NODE_GLOBAL + '/playwright')" && echo "playwright ok" || echo "missing: playwright"
command -v ffmpeg >/dev/null && echo "ffmpeg ok" || echo "missing: ffmpeg"
python3 -c "import numpy, scipy, PIL" && echo "python ok" || echo "missing: numpy, scipy or pillow"
```

What it does:

1. **The engine.** It copies `scripts/` and `references/` to `/home/claude/creator/.engine/`, and unpacks `assets.tar.gz` there as `assets/`. That is the engine folder.
2. **The work folder.** `/home/claude/creator/` is a copy of the user's notes layout. Every notes path in this skill, such as `00 - notes/ideas/` or `03 - export/<YYYY-MM-DD>-<slug>/`, is inside it.
3. **Chromium.** `REEL_CHROME` is the first match of `/opt/pw-browsers/chromium-*/chrome-linux*/chrome`, the sandbox's own Chromium. Capture uses it instead of Google Chrome.
4. **Playwright.** `capture.mjs` loads `playwright` from `NODE_GLOBAL`, which comes from `npm root -g`. If only `playwright-core` is there, the setup links it as `playwright` in `/home/claude/creator/.node/`.
   If it has to install `playwright-core`, it picks the version of the sandbox's Python `playwright` package, because that one matches the sandbox Chromium; with no Python package it takes the latest.
5. **Python** needs numpy, scipy and pillow. The sandbox has them.

If a line says `missing:`, tell the user in one plain line and stop. If Chromium is missing or will not start, the backup page (`references/sections/backup-page.md`) still makes the video.

Run every engine command like this, so the settings are there each time:

```text
. /home/claude/creator/.engine/env.sh && cd /home/claude/creator && <command>
```

## The user's Project files

The Project holds four files, and a fifth one, `templates.md`, once the user saves a carousel template. They are the real copy of the user's page:

| Project file | Copy it to, in the work folder |
|---|---|
| `brand.md` | `00 - notes/context/declared/brand.md` |
| `taste.md` | `00 - notes/context/observed/taste.md` |
| `ideas.md` | one note per idea in `00 - notes/ideas/` |
| `ledger.md` | `00 - notes/ledger.md` |
| `templates.md` (optional) | `00 - notes/context/declared/templates.md` |

At the start of the chat, after Setup, copy each Project file over the empty one in the work folder. Find the files with `find / -name brand.md -not -path "*reel-skill-chat*" -not -path "/home/claude/*" 2>/dev/null` (the copies under `/home/claude/` are the empty ones from Setup). If they are not on disk, write them from the Project text. A file the Project does not have yet keeps the empty copy from the setup. `templates.md` is optional: with no `templates.md`, the user has no saved templates, and every flow still works.

`ideas.md` holds every idea note in one file: each idea starts with a `## <note name>` line, then the note exactly as it is, frontmatter included. Split it into `00 - notes/ideas/<note name>.md`. Join it back the same way when you save.

## Save back

The work folder is gone when the chat ends. Only the Project files stay. So:

1. **At the end of any flow that changed `brand.md`, `taste.md`, an idea note or `ledger.md`, hand back those files** as files the user can download. That is every reel, every carousel and every review, and also new ideas (`creator:ideas`, made-up story Scout), a saved source (`creator:save`), the brand interview, a post link added to the ledger, and any idea `status` change. `ideas.md` is all notes in `00 - notes/ideas/` joined (not `_template.md` or `_index.md`). After a reel, a carousel and a review, always hand back `taste.md`.
   After a carousel template is saved, also hand back `templates.md`, with every template in it (one `## <name>` section each).
2. Say in one line: "Replace these in your Project files, so the next chat knows what you like."
3. Also save the new lesson in chat memory as a backup, one short line that starts with "Reel skill lesson:". If memory is off, say so in one line and go on.
4. With a finished reel, also hand back its `script.md`, so the user can attach it later to redo the caption or the reel.
5. Raw sources in `00 - notes/sources/` are not kept in chat. What a source teaches lives on in the ideas and `taste.md` you hand back.

## Chat rules that win

These replace the desktop parts of the section files. Where a section file says otherwise, these win.

1. **Paths.** `/home/claude/creator/.engine/` is the engine folder. A path that starts with `scripts/`, `assets/` or `references/`, or a link with no folder in front, is inside the engine folder. The `S/` of the build section is `/home/claude/creator/.engine/scripts/`.
2. **Questions.** There are no buttons here. Where a section says buttons or AskUserQuestion, write the question with 2 to 4 numbered choices, mark the pick, and leave room for the user's own words.
3. **No boards, no Obsidian, no Zernio, no slash commands.** Skip any step about boards, the Idea Board, Obsidian, `index.md` or `log.md`. The user posts and pulls numbers themselves: for a review, ask for a screenshot of the reel's Insights.
4. **Sources.** Read sunnah.com and quran.com with your own web fetch, not `source.mjs`. Every other source is read with web fetch too.
5. **Reciter audio.** On an Islamic page the user attaches the reciter MP3, because the reciter site is blocked here. Ask for it before the storyboard. Never make a computer voice read the Qur'an.
6. **Voiceover is no** in this chat. Do not ask it. A voice key cannot be kept safe in a chat.
7. **Sounds.** The 34 hits in `assets/sfx/` are ready. SFX Kit sounds (`kit:<id>`) are fetched one by one from `raw.githubusercontent.com/wyzowl/sfx-kit/main/` and checked by sha256. Before each render run `python3 -I /home/claude/creator/.engine/scripts/get-sounds.py /home/claude/creator/.engine "00 - notes/content/<slug>"`. If a sound will not download, pick another one in the catalogue.
8. **Beds.** The 13 beds in `assets/sfx/beds/` are ready: name one in the reel's `bed.txt` as `references/sound.md` says, or write `none`. A bed made with ElevenLabs is not possible here, so pick one of these 13.
9. **Preview.** There is no live preview server and no browser pane. In the build, the contact sheet of stills (`sheet.mjs`) is the preview: show it as an image. The storyboard is the beat table, shown as a table in the reply: no storyboard.html.
10. **Render time.** The sandbox has 2 CPUs. A 10 s reel takes about a minute and a half, a 60 s reel about 8 minutes. Run it in the background (`nohup bash /home/claude/creator/.engine/scripts/render.sh "<folder>" > "<folder>/render.log" 2>&1 &`), check the log every minute or so, and tell the user it is working.
11. **The finished MP4.** Copy `reel.mp4` and `poster.jpg` from `03 - export/<YYYY-MM-DD>-<slug>/` to `/mnt/user-data/outputs/` if that folder exists, and give the user the file. If it does not exist, offer the MP4 as a file in the reply.
12. **One reel at a time.** No background helpers. Bulk prep runs the reels one after another.
13. **The backup page.** If the render cannot work here, read `references/sections/backup-page.md`.

## Sections

Read a file only when a step needs it. Paths are inside the engine folder.

| File | Section | Read it when |
|---|---|---|
| `references/sections/flow-start.md` | Flow: creator:start | Brand interview, then your first reel. Run once after setup, or again to change your brand. |
| `references/sections/flow-today.md` | Flow: creator:today | What to do today. The make-next pick, what is due to post, and what is ready to review. |
| `references/sections/flow-ideas.md` | Flow: creator:ideas | New reel ideas into your ideas folder, real lessons and made-up stories, with no repeats. |
| `references/sections/flow-save.md` | Flow: creator:save | Save a source (a link, an article, a video, a note or a file) and file what it teaches into your notes. |
| `references/sections/flow-review.md` | Flow: creator:review | Your 48 hour numbers into the ledger, then lessons into taste.md and a pick for what to make next. |
| `references/sections/flow-reel.md` | Flow: creator:reel | Idea to finished MP4, then the caption. Give an idea, a topic, or a made-up story to tell. |
| `references/sections/flow-carousel.md` | Flow: creator:carousel | Idea to finished carousel, then the caption. Give a topic, your own text, a finished reel, or a template name. |
| `references/sections/helper-idea-scout.md` | Helper: Idea scout | Use this helper when the user wants new reel ideas for their page. Typical triggers include "give me ideas", "new ideas about X", "a made-up story about X", and the first-reel step of the start interview, which needs 3 ideas. It writes one idea note per idea in 00 - notes/ideas/, real lessons and made-up stories both. See "When to invoke" below. |
| `references/sections/helper-script-writer.md` | Helper: Script writer | Use this helper for step 1 of a reel, when an idea or topic must become a checked script. Typical triggers include creator:reel on a picked idea, "write the script for X", and "make a made-up story about X into a reel". A real lesson goes through mg-reel-topic then mg-reel-story; a made-up story goes through mg-reel-parable in Script mode. It writes script.md in the reel folder. See "When to invoke" below. |
| `references/sections/helper-reel-maker.md` | Helper: Reel maker | Use this helper for steps 2 to 5 of a reel, once the script is approved. Typical triggers include creator:reel after the Script writer is done, "pick the look", "make the storyboard", "build it", "render it", and resuming a reel folder whose script.md is at status story done or later. It runs mg-reel-style, mg-reel-storyboard and mg-reel-build and delivers the MP4 in 03 - export/. See "When to invoke" below. |
| `references/sections/helper-caption-helper.md` | Helper: Caption helper | Use this helper at the end of a reel, or whenever the user wants post text. Typical triggers include the end of creator:reel, "write a caption", "Threads post", and "here is my post link". It writes the caption and a matching Threads post into the reel folder, and when the user gives the post link it adds the ledger row and marks the idea posted. See "When to invoke" below. |
| `references/sections/helper-coach.md` | Helper: Coach | Use this helper to turn post numbers and taste into lessons and a pick for what to make next. Typical triggers include creator:review after the 48 hour numbers are in the ledger, creator:today when it needs the make-next pick, and "what should I make next". It writes lessons in taste.md and names one idea to make next. See "When to invoke" below. |
| `references/sections/mg-reel.md` | The reel chain: `mg-reel` | The reel chain |
| `references/sections/mg-reel-topic.md` | Step 1, sources: `mg-reel-topic` | Step 1, sources |
| `references/sections/mg-reel-story.md` | Step 2, story: `mg-reel-story` | Step 2, story |
| `references/sections/mg-reel-style.md` | Step 3, look: `mg-reel-style` | Step 3, look |
| `references/sections/mg-reel-storyboard.md` | Step 4, storyboard: `mg-reel-storyboard` | Step 4, storyboard |
| `references/sections/mg-reel-build.md` | Step 5, build and render: `mg-reel-build` | Step 5, build and render |
| `references/sections/mg-reel-parable.md` | Made-up stories: `mg-reel-parable` | Made-up stories |
| `references/sections/mg-carousel.md` | The carousel: `mg-carousel` | Making a carousel |
| `references/sections/backup-page.md` | If the render fails here | Only when the render cannot work in this chat |
