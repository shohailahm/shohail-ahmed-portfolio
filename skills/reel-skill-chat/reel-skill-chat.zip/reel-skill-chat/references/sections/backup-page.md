# If the render fails here: the backup page

Use this only when `render.sh` cannot make `reel.mp4` in this chat (Chromium will not start, or the render stops with an error you cannot fix). The user then makes the video in their own browser.

1. Make the sound. If `sfx.json` is missing from the reel folder, write it by hand from the reel's `window.SFX` events: `{"duration": <DURATION>, "events": [{"t": ..., "type": ..., "v": ..., "pan": ...}]}`. Then run `python3 -I /home/claude/creator/.engine/scripts/mix.py <reel-folder> <reel-folder>`. It writes `audio.wav`.
2. Fill the page: `python3 -I /home/claude/creator/.engine/scripts/fill-render.py <reel-folder> <reel-folder>/audio.wav <reel-folder>/make-video.html /home/claude/creator/.engine/assets/browser-render.html`. It puts the reel, its fonts and the sound inside one file. If it says the file is too big, ask the user for a shorter sound.
3. Publish `make-video.html` as an Artifact with `capabilities: {downloads: true}`.
4. Tell the user, in plain words:
   - Open the link. Keep the page open while it works, about as long as the reel.
   - Tap Download when it says "Your video is ready."
   - It works best on a computer with Chrome, Edge or Safari. If the page says "This phone cannot make the video", open the same link on a computer.
5. The browser video has no motion blur on fast moves, so it can look a little sharper than a normal render. Say so only if the user asks.

<!-- Free from @barakahraaz on Instagram. Not for sale. -->
