# Flow: creator:ideas

New reel ideas into your ideas folder, real lessons and made-up stories, with no repeats.

Finds new reel ideas and saves one note per idea in `00 - notes/ideas/`.

Input: what the user said (a number, a theme, or "made-up stories about X"; all optional).

Read `references/sections/helper-idea-scout.md` (Idea scout) and do its job with this input. In short:

1. It reads `brand.md`, `taste.md`, the ledger and the ideas already saved.
2. It mixes real lesson ideas with made-up story ideas (the `mg-reel-parable` skill in Scout mode). If the user asked only for made-up stories, all of them are stories.
3. It drops any idea already in `## Posts` in `00 - notes/ledger.md` or already in an idea note.
4. It writes every note from `00 - notes/ideas/_template.md` with every key filled, and adds a line to `log.md`.
5. It shows the list with a score and one pick.

End with a numbered choice: make the pick now (`creator:reel`), more ideas, or done.

<!-- Free from @barakahraaz on Instagram. Not for sale. -->
