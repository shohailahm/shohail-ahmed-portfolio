# Step 3, look: `mg-reel-style`

Picks how the reel looks, with one still per option, because three full builds were once all rejected when one still each would have caught it. Reads `script.md` (`## Treatment`, `## Copy`, `## What the viewer watches`). The look serves the picked treatment: its world, signature move and hero sequence must work in it. Shared rules: `references/sections/mg-reel.md` and `/home/claude/creator/.engine/references/rules.md`, section "Direction".

A style is only a look: material, palette, texture, light, motion. Never tie it to its example props or topics; any style can draw anything the story needs.

```text
Style progress:
- [ ] 0 Rules read
- [ ] 1 Two or three looks pitched
- [ ] 2 One key still, for the look to build
- [ ] 3 Look picked, status: style done
```

0. **Read the rules first,** even when this step runs alone, because the numbers live only there. Read "Fixed for every reel" and "Brand constants" in `references/sections/mg-reel.md`, and the "Direction" section of `/home/claude/creator/.engine/references/rules.md`. If the reel folder has no `rules.md`, copy it there. Done when read.
1. **Pitch.** First read the looks the user liked in `00 - notes/context/observed/taste.md`, and the Cinema night look in `references/look.md`. Pitch from those first. Never pitch Paper diorama or Sumi-e wash for a reel with human figures. If the user named one or two styles in the question round, those are the pitch: add nothing. Otherwise pitch two or three picture styles that differ in kind, not colour (a type style, marked in the index, only when the user asks for type), each by its gallery name so the user can watch it at https://barakahraaz.pages.dev/styles, from `/home/claude/creator/.engine/references/styles/index.md` (each recipe has Look, Motion, How it explains, and a working page in `/home/claude/creator/.engine/assets/styles/`). A recipe's **Production readiness** line says whether the style has held a full reel; a `needs work` style can still be pitched, with its gaps named. Open `/home/claude/creator/.engine/references/look.md` for looks tried and the cinema night look. Name the palette for each: never the page colours by default, and "pastel" means many pastel palettes. Done when each look has a name, a palette and one line on why it fits the story.
2. **One key still, for the look to build.** First the user picks from the pitch (the gallery shows every look, so no still is needed to choose). Then draw the hero sequence's key moment (from `## Treatment`) in that look only, or in each style the user named (two at most); never one still per pitched look, because every still is a full page build and costs the user many tokens. Draw it in the look's real style code: start from the style's working page in `/home/claude/creator/.engine/assets/styles/`, never a quick sketch from zero, because flat from-zero sketches read as clip art, at 1080x1920, captured with `node /home/claude/creator/.engine/scripts/capture.mjs <folder> stills <t>`. Look at each at full size. The style pages show `@YOURPAGE`: swap it for `handle` from `00 - notes/context/declared/brand.md`. Draw objects, places and figures that act the moment out, never a screen of words (rules.md, Direction, Picture first). Done when the still is drawn and breaks no fixed rule (Islamic pages: no prophet drawn, no emblem or six-pointed star; every page: text clear of the Instagram zones).
3. **Record.** Write `## Look` in `script.md`: the style, the palette as hex values, the fonts, the texture, and the still's path. Set `status: style done`.

**Stop.** Show the still (two side by side if the user named two), with a pick. When the user picks, read `references/sections/mg-reel-storyboard.md`. If none fits, return to step 1 with what they disliked. In bulk prep (`reel` SKILL.md, Bulk prep), do not stop: write the question and the pick under `## Open questions` and go on.

<!-- Free from @barakahraaz on Instagram. Not for sale. -->
